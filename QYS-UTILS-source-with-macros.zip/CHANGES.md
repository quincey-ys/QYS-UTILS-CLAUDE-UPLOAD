# Change list (relative to QYS-AUTISM-CLIENT-ADDON zip)

## Added
- src/main/java/com/quinceyys/utils/CrystalMacroModule.java
- src/main/java/com/quinceyys/utils/AnchorMacroModule.java
- src/main/java/com/quinceyys/utils/AutoSprintModule.java
- src/main/resources/assets/qys_utils/font/*            (Lato font files copied from your built jar; they were missing from the zip)
- src/main/resources/META-INF/licenses/Lato-Font-Licenses.txt
- CHANGES.md

## Modified
- src/main/java/com/quinceyys/utils/QysUtilsConfigScreen.java  (tabbed/scrollable rewrite, 3 new tabs, persist() saves new modules)
- src/main/java/com/quinceyys/utils/QysUtilsClient.java        (initializes the 3 new modules)
- src/main/java/com/quinceyys/utils/AutoTotemModule.java       (new holeResistance setting; default = old hardcoded 600, behavior unchanged)
- src/main/java/com/quinceyys/utils/MaceHitterModule.java      (new slamRange setting; default = old hardcoded 6.0, behavior unchanged)
- src/main/resources/assets/qys_utils/lang/en_us.json           (3 key names)
- src/main/resources/fabric.mod.json                            (description only)
- README.md

## Deleted
- none

## Not needed / not changed
- No mixins, accessors or mixin JSON: everything uses Fabric API events (UseBlockCallback, ClientTickEvents) and the same game APIs the existing modules already call.
- build.gradle.kts, gradle.properties, libs.versions.toml unchanged (no new dependencies).

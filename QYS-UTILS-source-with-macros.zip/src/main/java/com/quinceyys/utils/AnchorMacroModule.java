package com.quinceyys.utils;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.util.InputConstants;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Anchor Macro: after YOU place a Respawn Anchor, charge it with Glowstone, swap back to
 * Respawn Anchors, and interact again to detonate it.
 *
 * Scoping: exactly one anchor position is tracked at a time. It is recorded only when you place an
 * anchor into a replaceable (empty) spot, so existing/unrelated anchors are never touched.
 *
 * Note: a Respawn Anchor only explodes outside the Nether. Inside the Nether the final
 * interaction just sets your spawn point (vanilla rule, not something this module changes).
 */
public final class AnchorMacroModule {
    private static final Path CONFIG = Path.of("config", "qys-anchor-macro.properties");

    private static KeyMapping toggleKey;

    public static boolean enabled = false;
    /** How many Glowstone interactions to perform before detonating (1-4). */
    public static int glowstoneCharges = 1;
    /** Ticks to wait between steps. 0 = run the whole sequence in a single tick. */
    public static int stepDelayTicks = 0;
    /** How many ticks to wait for the placed anchor to appear before giving up. */
    public static int windowTicks = 10;

    private enum Stage { WAIT_BLOCK, CHARGE, SWAP_BACK, DETONATE }

    private static BlockPos targetPos;
    private static Direction targetFace = Direction.UP;
    private static Stage stage = Stage.WAIT_BLOCK;
    private static int expiresAt;
    private static int cooldown;
    private static int chargesDone;
    private static int originalSlot;
    private static int tickCounter;
    private static boolean internalInteract;

    private AnchorMacroModule() {}

    public static void initialize() {
        loadConfig();

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.qys_utils.anchor_toggle", InputConstants.UNKNOWN.getValue(), KeyMapping.Category.MISC
        ));

        UseBlockCallback.EVENT.register(AnchorMacroModule::onUseBlock);
        ClientTickEvents.END_CLIENT_TICK.register(AnchorMacroModule::onEndTick);
    }

    private static InteractionResult onUseBlock(Player player, Level level, InteractionHand hand, BlockHitResult hit) {
        if (!enabled || internalInteract) return InteractionResult.PASS;

        Minecraft client = Minecraft.getInstance();
        if (player != client.player) return InteractionResult.PASS;
        if (!player.getItemInHand(hand).is(Items.RESPAWN_ANCHOR)) return InteractionResult.PASS;
        if (targetPos != null) return InteractionResult.PASS; // one sequence at a time

        BlockPos clickedPos = hit.getBlockPos();
        BlockState clicked = level.getBlockState(clickedPos);
        if (clicked.is(Blocks.RESPAWN_ANCHOR)) return InteractionResult.PASS; // interacting, not placing

        BlockPos placePos = clicked.canBeReplaced() ? clickedPos : clickedPos.relative(hit.getDirection());
        if (!level.getBlockState(placePos).canBeReplaced()) return InteractionResult.PASS; // nothing will be placed

        targetPos = placePos;
        targetFace = hit.getDirection();
        stage = Stage.WAIT_BLOCK;
        expiresAt = tickCounter + windowTicks;
        cooldown = 0;
        chargesDone = 0;
        return InteractionResult.PASS;
    }

    private static void onEndTick(Minecraft client) {
        tickCounter++;

        while (toggleKey.consumeClick()) {
            enabled = !enabled;
            saveConfig();
            if (!enabled) reset();
        }

        LocalPlayer player = client.player;
        if (!enabled || player == null || client.level == null || client.gameMode == null) {
            reset();
            return;
        }
        if (targetPos == null) return;

        // Vanilla ignores block interactions while sneaking with an item, so the sequence cannot work.
        if (player.isShiftKeyDown()) {
            reset();
            return;
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        while (targetPos != null) {
            switch (stage) {
                case WAIT_BLOCK -> {
                    if (tickCounter > expiresAt) {
                        reset();
                        return;
                    }
                    if (!client.level.getBlockState(targetPos).is(Blocks.RESPAWN_ANCHOR)) return;
                    originalSlot = player.getInventory().getSelectedSlot();
                    chargesDone = 0;
                    stage = Stage.CHARGE;
                }
                case CHARGE -> {
                    int slot = findHotbarSlot(player, Items.GLOWSTONE);
                    if (slot < 0) {
                        reset();
                        return;
                    }
                    player.getInventory().setSelectedSlot(slot);
                    interact(client, player);
                    chargesDone++;
                    if (chargesDone >= glowstoneCharges) stage = Stage.SWAP_BACK;
                    if (stepDelayTicks > 0) {
                        cooldown = stepDelayTicks;
                        return;
                    }
                }
                case SWAP_BACK -> {
                    int slot = findHotbarSlot(player, Items.RESPAWN_ANCHOR);
                    player.getInventory().setSelectedSlot(slot >= 0 ? slot : originalSlot);
                    stage = Stage.DETONATE;
                    if (stepDelayTicks > 0) {
                        cooldown = stepDelayTicks;
                        return;
                    }
                }
                case DETONATE -> {
                    interact(client, player);
                    reset();
                    return;
                }
            }
        }
    }

    private static void interact(Minecraft client, LocalPlayer player) {
        Vec3 center = Vec3.atCenterOf(targetPos);
        Vec3 location = new Vec3(
                center.x + targetFace.getStepX() * 0.5,
                center.y + targetFace.getStepY() * 0.5,
                center.z + targetFace.getStepZ() * 0.5
        );
        BlockHitResult hit = new BlockHitResult(location, targetFace, targetPos, false);

        internalInteract = true;
        try {
            client.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, hit);
            player.swing(InteractionHand.MAIN_HAND);
        } finally {
            internalInteract = false;
        }
    }

    private static int findHotbarSlot(LocalPlayer player, Item item) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getItem(slot).is(item)) return slot;
        }
        return -1;
    }

    private static void reset() {
        targetPos = null;
        stage = Stage.WAIT_BLOCK;
        cooldown = 0;
        chargesDone = 0;
    }

    public static void loadConfig() {
        Properties properties = new Properties();
        try {
            Files.createDirectories(CONFIG.getParent());
            if (Files.exists(CONFIG)) {
                try (InputStream input = Files.newInputStream(CONFIG)) {
                    properties.load(input);
                }
            }
            enabled = bool(properties, "enabled", false);
            glowstoneCharges = integer(properties, "glowstoneCharges", 1, 1, 4);
            stepDelayTicks = integer(properties, "stepDelayTicks", 0, 0, 10);
            windowTicks = integer(properties, "windowTicks", 10, 1, 40);
            saveConfig();
        } catch (IOException exception) {
            System.err.println("[QYS-UTILS/AnchorMacro] Config load failed: " + exception.getMessage());
        }
    }

    public static void saveConfig() {
        Properties properties = new Properties();
        properties.setProperty("enabled", Boolean.toString(enabled));
        properties.setProperty("glowstoneCharges", Integer.toString(glowstoneCharges));
        properties.setProperty("stepDelayTicks", Integer.toString(stepDelayTicks));
        properties.setProperty("windowTicks", Integer.toString(windowTicks));
        try {
            Files.createDirectories(CONFIG.getParent());
            try (OutputStream output = Files.newOutputStream(CONFIG)) {
                properties.store(output, "QYS-UTILS Anchor Macro settings");
            }
        } catch (IOException exception) {
            System.err.println("[QYS-UTILS/AnchorMacro] Config save failed: " + exception.getMessage());
        }
    }

    private static boolean bool(Properties properties, String key, boolean fallback) {
        return Boolean.parseBoolean(properties.getProperty(key, Boolean.toString(fallback)));
    }

    private static int integer(Properties properties, String key, int fallback, int min, int max) {
        try {
            return Math.max(min, Math.min(max,
                    Integer.parseInt(properties.getProperty(key, Integer.toString(fallback)))));
        } catch (NumberFormatException exception) {
            return fallback;
        }
    }
}

package com.quinceyys.utils;

import net.fabricmc.api.ClientModInitializer;

public final class QysUtilsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        AutoTotemModule.initialize();
        MaceHitterModule.initialize();
        CrystalMacroModule.initialize();
        AnchorMacroModule.initialize();
        AutoSprintModule.initialize();
        System.out.println("[QYS-UTILS] AutoTotem, Mace Hitter, Crystal Macro, Anchor Macro and Auto Sprint initialized.");
    }
}

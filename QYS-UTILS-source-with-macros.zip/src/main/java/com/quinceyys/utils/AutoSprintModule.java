package com.quinceyys.utils;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.util.InputConstants;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Auto Sprint: holds the vanilla Sprint key while the Forward key is held.
 *
 * It deliberately does NOT call setSprinting() itself. It only presses the real Sprint key
 * binding, so every vanilla rule (hunger, blindness, collision, swimming, using items,
 * riding, ...) still decides whether the player actually sprints.
 * The key is only pressed when it is not already down (so manual sprint is never fought),
 * and it is released the moment forward movement stops.
 */
public final class AutoSprintModule {
    private static final Path CONFIG = Path.of("config", "qys-auto-sprint.properties");

    private static KeyMapping toggleKey;

    public static boolean enabled = false;
    /** Do not hold sprint while sneaking. */
    public static boolean pauseWhileSneaking = true;

    private static boolean heldByMod;

    private AutoSprintModule() {}

    public static void initialize() {
        loadConfig();

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.qys_utils.sprint_toggle", InputConstants.UNKNOWN.getValue(), KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(AutoSprintModule::onEndTick);
    }

    private static void onEndTick(Minecraft client) {
        while (toggleKey.consumeClick()) {
            enabled = !enabled;
            saveConfig();
            if (!enabled) release(client);
        }

        LocalPlayer player = client.player;
        if (!enabled || player == null || client.level == null || client.gui.screen() != null) {
            release(client);
            return;
        }

        boolean forward = client.options.keyUp.isDown();
        if (!forward || (pauseWhileSneaking && player.isShiftKeyDown())) {
            release(client);
            return;
        }

        if (!client.options.keySprint.isDown()) {
            client.options.keySprint.setDown(true);
            heldByMod = true;
        }
    }

    private static void release(Minecraft client) {
        if (heldByMod) {
            client.options.keySprint.setDown(false);
            heldByMod = false;
        }
    }

    public static void loadConfig() {
        Properties properties = new Properties();
        try {
            Files.createDirectories(CONFIG.getParent());
            if (Files.exists(CONFIG)) {
                try (InputStream input = Files.newInputStream(CONFIG)) {
                    properties.load(input);
                }
            }
            enabled = bool(properties, "enabled", false);
            pauseWhileSneaking = bool(properties, "pauseWhileSneaking", true);
            saveConfig();
        } catch (IOException exception) {
            System.err.println("[QYS-UTILS/AutoSprint] Config load failed: " + exception.getMessage());
        }
    }

    public static void saveConfig() {
        Properties properties = new Properties();
        properties.setProperty("enabled", Boolean.toString(enabled));
        properties.setProperty("pauseWhileSneaking", Boolean.toString(pauseWhileSneaking));
        try {
            Files.createDirectories(CONFIG.getParent());
            try (OutputStream output = Files.newOutputStream(CONFIG)) {
                properties.store(output, "QYS-UTILS Auto Sprint settings");
            }
        } catch (IOException exception) {
            System.err.println("[QYS-UTILS/AutoSprint] Config save failed: " + exception.getMessage());
        }
    }

    private static boolean bool(Properties properties, String key, boolean fallback) {
        return Boolean.parseBoolean(properties.getProperty(key, Boolean.toString(fallback)));
    }
}

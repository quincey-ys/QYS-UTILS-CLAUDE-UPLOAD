# QYS-UTILS

Standalone Fabric client utility mod for Minecraft Java 26.3. This is one independent mod JAR, not an AUTISM Client addon.

## Included modules

### AutoTotem
- Smart, Switch, and PickUp modes.
- Health threshold and projected fall-damage triggers.
- Missing-armor trigger.
- Safety threshold, safe switch-back delay, and blast-resistant-hole check.
- Optional Elytra ignore.
- Existing AutoTotem settings are retained in config/autism-autototem.properties.

### Mace Hitter
- Nearest-target selection with configurable range.
- Player-only or all-living-entity targeting.
- Optional line-of-sight and teammate checks.
- Automatic hotbar mace selection and jump assistance.
- Optional falling-only attacks and shield-stun priority.
- Configurable attack delay and manual Slam Now action.

### Crystal Macro
- Breaks an End Crystal you just placed (only at the exact position you placed it, once).
- Placing window, attack range, swing toggle. Toggle key unbound by default.

### Anchor Macro
- After you place a Respawn Anchor: Glowstone charge(s), swap back to anchors, detonate.
- Glowstone charge count, step delay, placing window. Toggle key unbound by default.

### Auto Sprint
- Holds the vanilla Sprint key while Forward is held; vanilla sprint rules still apply.
- Optional pause while sneaking. Toggle key unbound by default.

## Shared settings screen

Press O to open the unified QYS-UTILS settings screen. It contains AutoTotem and Mace Hitter tabs, opaque panels with squircle corners, and settings controls. Changes save immediately and again when the screen closes.

## Keybinds
- T: Toggle AutoTotem
- O: Open QYS-UTILS settings
- R: Toggle Mace Hitter
- G: Slam Now

All keybinds can be changed under Options > Controls > Key Binds.

## Configuration files
- config/autism-autototem.properties
- config/qys-mace-hitter.properties
- config/qys-crystal-macro.properties
- config/qys-anchor-macro.properties
- config/qys-auto-sprint.properties

The AutoTotem config filename and property names are kept compatible with the original QYS AutoTotem config.

## Requirements
- Minecraft Java Edition 26.3
- Fabric Loader 0.20.1 or newer
- Fabric API for 26.3
- Java 25

## Build
Run Gradle 9.8.2 with Java 25 and execute gradle build. The distributable mod is written to build/libs/QYS-UTILS.jar.
